﻿Clear-Host

if (-not (([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))) {
    Write-Warning 'This script requires ADMIN permissions. Please run it as Administrator.'
    Write-Host 'Press Any Key to exit...'
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
    return
}

Write-Host 'The script has launched...' -ForegroundColor DarkGreen
Write-Host ''

$totalSteps = 34
$currentStep = 0

function Update-ProgressBar {
    param (
        [int]$step
    )

    $percentComplete = [math]::Round(($step / $totalSteps) * 100)
    Write-Progress -Activity 'Configuring System' -Status "$percentComplete% Complete" -PercentComplete $percentComplete
}

$targetComputerName = 'ALCOMP05'

if ($env:COMPUTERNAME -eq $targetComputerName) {
    Write-Host "Current PC name is '$targetComputerName'. Skipping rename." -ForegroundColor DarkGray
}
else {
    try {
        Rename-Computer -NewName $targetComputerName -Force -ErrorAction SilentlyContinue
        Write-Host "PC name set to '$targetComputerName'." -ForegroundColor DarkBlue
        $currentStep++
        Update-ProgressBar -Step $currentStep
    }
    catch {
        Write-Warning "Failed to rename PC: $($_.Exception.Message)"
    }
}

Write-Host ''

$targetUser = 'helper'

try {
    $helperUser = Get-LocalUser -Name $targetUser -ErrorAction SilentlyContinue
    if ($helperUser) {
        $adminUser = Get-LocalUser -Name 'Administrator' -ErrorAction SilentlyContinue
        if (-not $adminUser) {
            $adminUser = Get-LocalUser -Name 'Администратор' -ErrorAction SilentlyContinue
        }

        if ($adminUser) {
            Remove-LocalUser -Name $targetUser -Confirm:$false
            Write-Host "User '$targetUser' removed because an Administrator account already exists." -ForegroundColor DarkBlue
        }
        else {
            $culture = Get-Culture
            $newAdminName = if ($culture.Name -like 'ru-*') { 'Администратор' } else { 'Administrator' }
            Rename-LocalUser -Name $targetUser -NewName $newAdminName
            Write-Host "User '$targetUser' renamed to '$newAdminName'." -ForegroundColor DarkBlue
        }
    }
    else {
        Write-Host "User '$targetUser' does not exist." -ForegroundColor DarkGray
    }

    $adminUser = Get-LocalUser -Name 'Administrator' -ErrorAction SilentlyContinue
    if (-not $adminUser) {
        $adminUser = Get-LocalUser -Name 'Администратор' -ErrorAction SilentlyContinue
    }
    if ($adminUser) {
        Disable-LocalUser -Name $adminUser.Name
        Write-Host "User '$($adminUser.Name)' disabled." -ForegroundColor DarkBlue
    }

    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "An error occurred during user management for '$targetUser': $($_.Exception.Message)"
}

Write-Host ''

try {
    powercfg.exe /change /standby-timeout-ac 30
    Write-Host 'Standby timeout (AC) set to 30 minutes.' -ForegroundColor DarkBlue
    powercfg.exe /change /standby-timeout-dc 10
    Write-Host 'Standby timeout (DC) set to 10 minutes.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set standby timeouts: $($_.Exception.Message)"
}

try {
    powercfg.exe /change /monitor-timeout-ac 20
    Write-Host 'Monitor timeout (AC) set to 20 minutes.' -ForegroundColor DarkBlue
    powercfg.exe /change /monitor-timeout-dc 5
    Write-Host 'Monitor timeout (DC) set to 5 minutes.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set monitor timeouts: $($_.Exception.Message)"
}

Write-Host ''

Start-Sleep -Seconds 3

try {
    powercfg.exe /SETACVALUEINDEX scheme_current sub_buttons LIDACTION 1
    Write-Host 'LIDACTION (AC) set to 1.' -ForegroundColor DarkBlue
    powercfg.exe /SETDCVALUEINDEX scheme_current sub_buttons LIDACTION 3
    Write-Host 'LIDACTION (DC) set to 3.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set LIDACTION: $($_.Exception.Message)"
}

try {
    powercfg.exe /SETACVALUEINDEX scheme_current sub_buttons PBUTTONACTION 3
    Write-Host 'PBUTTONACTION (AC) set to 3.' -ForegroundColor DarkBlue
    powercfg.exe /SETDCVALUEINDEX scheme_current sub_buttons PBUTTONACTION 3
    Write-Host 'PBUTTONACTION (DC) set to 3.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set PBUTTONACTION: $($_.Exception.Message)"
}

try {
    powercfg.exe /SETACVALUEINDEX scheme_current sub_buttons SBUTTONACTION 1
    Write-Host 'SBUTTONACTION (AC) set to 1.' -ForegroundColor DarkBlue
    powercfg.exe /SETDCVALUEINDEX scheme_current sub_buttons SBUTTONACTION 1
    Write-Host 'SBUTTONACTION (DC) set to 1.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set SBUTTONACTION: $($_.Exception.Message)"
}

Write-Host ''

try {
    powercfg.exe /SETACVALUEINDEX scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
    Write-Host 'USB Selective Suspend (AC) disabled.' -ForegroundColor DarkBlue
    powercfg.exe /SETDCVALUEINDEX scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0
    Write-Host 'USB Selective Suspend (DC) disabled.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to disable USB Selective Suspend: $($_.Exception.Message)"
}

try {
    powercfg.exe /change /disk-timeout-ac 0
    Write-Host 'Disk timeout (AC) set to 0 minutes.' -ForegroundColor DarkBlue
    powercfg.exe /change /disk-timeout-dc 0
    Write-Host 'Disk timeout (DC) set to 0 minutes.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set disk timeouts: $($_.Exception.Message)"
}

Write-Host ''

try {
    Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Remote Assistance" -Name fAllowToGetHelp -Value 0 -Type DWord -Force
    Write-Host 'Remote Assistance (Get Help) disabled.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to disable Remote Assistance (Get Help): $($_.Exception.Message)"
}

try {
    Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Remote Assistance" -Name fAllowFullControl -Value 0 -Type DWord -Force
    Write-Host 'Remote Assistance (Full Control) disabled.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to disable Remote Assistance (Full Control): $($_.Exception.Message)"
}

try {
    Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server" -Name fDenyTSConnections -Value 1 -Type DWord -Force
    Write-Host 'Remote Desktop disabled.' -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to disable Remote Desktop: $($_.Exception.Message)"
}

try {
    Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Name UserAuthentication -Value 1 -Type DWord -Force
    Write-Host "Remote Desktop User Authentication set to require 'Network Level Authentication'." -ForegroundColor DarkBlue
    $currentStep++
    Update-ProgressBar -Step $currentStep
}
catch {
    Write-Warning "Failed to set Remote Desktop User Authentication: $($_.Exception.Message)"
}

Write-Host ''

try {
Get-NetFirewallRule -Name 'RemoteDesktop-UserMode-In-TCP', 'RemoteDesktop-Shadow-In-TCP', 'RemoteDesktop-UserMode-In-UDP', 'RemoteDesktop-In-TCP-WSS', 'RemoteDesktop-In-TCP-WS' | Disable-NetFirewallRule
}
catch {
    Write-Warning "Failed to disable Remote Desktop firewall rules: $($_.Exception.Message)"
}

$anyDeskProcessName = 'AnyDesk'
$anyDeskAppDataPath = Join-Path -Path $env:APPDATA -ChildPath $anyDeskProcessName
$anyDeskProgramFilesPath = "C:\Program Files (x86)\AnyDesk\AnyDesk.exe"
$anyDeskProgramDataPath = 'C:\ProgramData\AnyDesk\AnyDesk.exe'

function Stop-AnyDeskProcess {
    $runningProcess = Get-Process -Name $anyDeskProcessName -ErrorAction SilentlyContinue
    if ($runningProcess) {
        $runningProcess | Stop-Process -Force
        Write-Host "Process '$anyDeskProcessName' terminated." -ForegroundColor DarkBlue
    }
    else {
        Write-Host "Process '$anyDeskProcessName' not found." -ForegroundColor DarkGray
    }
}

function Uninstall-AnyDesk {
    param (
        [string]$Path,
        [string]$Description
    )

    if (Test-Path -Path $Path) {
        try {
            Start-Process -FilePath $Path -ArgumentList '--silent', '--remove' -Wait
            Write-Host "AnyDesk uninstalled from '$Description'." -ForegroundColor DarkBlue
        }
        catch {
            Write-Warning "Error uninstalling AnyDesk from '$Description': $($_.Exception.Message)"
        }
    }
    else {
        Write-Host "AnyDesk not found for uninstallation in '$Description'." -ForegroundColor DarkGray
    }
}

function Remove-AnyDeskFolders {
    $folders = @(
        'C:\ProgramData\AnyDesk'
        "C:\Program Files (x86)\AnyDesk"
        "C:\Program Files\AnyDesk"
        $anyDeskAppDataPath
    )
    foreach ($folder in $folders) {
        Remove-Folder -Path $folder -Description $folder
    }
}

function Remove-Folder {
    param (
        [string]$Path,
        [string]$Description
    )

    if (Test-Path -Path $Path) {
        try {
            Remove-Item -Path $Path -Recurse -Force
            Write-Host "Folder '$Description' removed." -ForegroundColor DarkBlue
        }
        catch {
            Write-Warning "Error removing folder '$Description': $($_.Exception.Message)"
        }
    }
    else {
        Write-Host "Folder '$Description' not found." -ForegroundColor DarkGray
    }
}


Stop-AnyDeskProcess

$currentStep++
Update-ProgressBar -Step $currentStep
Start-Sleep -Seconds 3


Uninstall-AnyDesk -Path $anyDeskProgramFilesPath -Description 'Program Files (x86)'

$currentStep++
Update-ProgressBar -Step $currentStep
Start-Sleep -Seconds 3


Uninstall-AnyDesk -Path $anyDeskProgramDataPath -Description 'ProgramData'

$currentStep++
Update-ProgressBar -Step $currentStep
Start-Sleep -Seconds 3


Remove-AnyDeskFolders

$currentStep++
Update-ProgressBar -Step $currentStep
Start-Sleep -Seconds 3


Write-Host ''

Write-Host "The script has completed!`nReboot is required for all changes to take effect." -ForegroundColor DarkGreen



# try {
#     powercfg.exe /h off
#     Write-Host 'Hibernation disabled.' -ForegroundColor DarkBlue
#     $currentStep++
#     Update-ProgressBar -Step $currentStep
# }
# catch {
#     Write-Warning "Failed to disable hibernation: $($_.Exception.Message)"
# }
# 
# Write-Host ''

##################

# try {
#     $culture = Get-Culture
#     $displayGroups = if ($culture.Name -like 'ru-*') {
#         @(
#             'Веб-доступ к удаленным рабочим столам (WebSocket)'
#             'Дистанционное управление рабочим столом'
#         )
#     }
#     else {
#         @(
#             'Remote Desktop (WebSocket)'
#             'Remote Desktop'
#         )
#     }
#     foreach ($displayGroup in $displayGroups) {
#         $rules = Get-NetFirewallRule -DisplayGroup $displayGroup -ErrorAction SilentlyContinue
#         if ($rules) {
#             $rules | Disable-NetFirewallRule -Confirm:$false -ErrorAction Stop
#             Write-Host "Disabled firewall rule(s) for group '$displayGroup'." -ForegroundColor DarkBlue
#         }
#         else {
#             Write-Warning "No firewall rules found for group '$displayGroup'."
#         }
#     }
#     $currentStep++
#     Update-ProgressBar -Step $currentStep
# }
# catch {
#     Write-Warning "Failed to disable Remote Desktop firewall rules: $($_.Exception.Message)"
# }
# 
# Write-Host ''

# $shares = 'C$', 'D$', 'ADMIN$'
# 
# foreach ($share in $shares) {
#     try {
#         $existingShare = Get-SmbShare -Name $share -ErrorAction SilentlyContinue
#         if ($existingShare) {
#             $existingShare | Remove-SmbShare -Force -Confirm:$false
#             Write-Host "'$share' share deleted successfully." -ForegroundColor DarkBlue
#         }
#         else {
#             Write-Host "'$share' share does not exist. Skipping deletion." -ForegroundColor DarkGray
#         }
#     }
#     catch {
#         Write-Warning "Failed to delete '$share' share: $($_.Exception.Message)"
#     }
#     $currentStep++
#     Update-ProgressBar -Step $currentStep
# }
# 
# $regPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
# $autoShareWksKey = 'AutoShareWks'
# 
# try {
#     $autoShareWksValue = Get-ItemPropertyValue -Path $regPath -Name $autoShareWksKey -ErrorAction SilentlyContinue
#     if ($autoShareWksValue -ne $null) {
#         if ($autoShareWksValue -ne 0) {
#             Set-ItemProperty -Path $regPath -Name $autoShareWksKey -Value 0 -Type DWord -Force -ErrorAction Stop
#             Write-Host "'$autoShareWksKey' registry key set to '0' (disabled automatic share creation)." -ForegroundColor DarkBlue
#         }
#         else {
#             Write-Host "'$autoShareWksKey' registry key is already set to '0'. No action required." -ForegroundColor DarkGray
#         }
#     }
#     else {
#         New-ItemProperty -Path $regPath -Name $autoShareWksKey -Value 0 -PropertyType DWord -Force -ErrorAction Stop | Out-Null
#         Write-Host "'$autoShareWksKey' registry key created and set to '0' (disabled automatic share creation)." -ForegroundColor DarkBlue
#     }
#     $currentStep++
#     Update-ProgressBar -Step $currentStep
# }
# catch {
#     Write-Warning "Failed to set '$autoShareWksKey' registry key: $($_.Exception.Message)"
# }
# 
# $regPathLsa = 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'
# $restrictAnonymousKey = 'RestrictAnonymous'
# 
# try {
#     $restrictAnonymousValue = Get-ItemPropertyValue -Path $regPathLsa -Name $restrictAnonymousKey -ErrorAction SilentlyContinue
#     if ($restrictAnonymousValue -ne $null) {
#         if ($restrictAnonymousValue -ne 1) {
#             Set-ItemProperty -Path $regPathLsa -Name $restrictAnonymousKey -Value 1 -Type DWord -Force -ErrorAction Stop
#             Write-Host "Local Security Authority (LSA) '$restrictAnonymousKey' registry key set to '1'." -ForegroundColor DarkBlue
#         }
#         else {
#             Write-Host "Local Security Authority (LSA) '$restrictAnonymousKey' registry key already set to '1'. No action required." -ForegroundColor DarkGray
#         }
#     }
#     else {
#         New-ItemProperty -Path $regPathLsa -Name $restrictAnonymousKey -Value 1 -PropertyType DWord -Force -ErrorAction Stop | Out-Null
#         Write-Host "Local Security Authority (LSA) '$restrictAnonymousKey' registry key created and set to '1'." -ForegroundColor DarkBlue
#     }
#     $currentStep++
#     Update-ProgressBar -Step $currentStep
# }
# catch {
#     Write-Warning "Failed to set Local Security Authority (LSA) '$restrictAnonymousKey' registry key: $($_.Exception.Message)"
# }
# 
# Write-Host ''