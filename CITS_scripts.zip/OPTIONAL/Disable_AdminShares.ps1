﻿<#
    .SYNOPSIS
    Disables automatic creation of administrative shares and removes existing ones.
    .DESCRIPTION
    This script disables the automatic creation of administrative shares (C$, D$, ADMIN$)
    by modifying the registry. It also removes any existing administrative shares
    and restarts the 'Server' (LanmanServer) service to apply the changes.
    It is designed to work on both modern and legacy Windows systems.
#>
#Requires -RunAsAdministrator
# --------------------------------------------------------------
# 0. Output utilities
# --------------------------------------------------------------
Clear-Host
function Write-Info($msg) { Write-Host "ℹ️  $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "✅  $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "⚠️  $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "❌  $msg" -ForegroundColor Red }
# --------------------------------------------------------------
# 1. Administrator privileges check
# --------------------------------------------------------------
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Err "The script must be run as administrator."
    exit 1
}
Write-Host "`n===== START =====`n" -ForegroundColor Blue
Write-OK "Execution as administrator confirmed."
# --------------------------------------------------------------
# 2. Parameters (can be modified if necessary)
# --------------------------------------------------------------
$adminShares = @('C$', 'D$', 'ADMIN$')
$regPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters'
# --------------------------------------------------------------
# 3. Disable automatic creation of administrative shares
# --------------------------------------------------------------
function Set-RegValue {
    param(
        [string]$Path,
        [string]$Name,
        [int]$Value
    )
    try {
        Set-ItemProperty -Path $Path -Name $Name -Value $Value -Force -ErrorAction Stop
        Write-OK "$Name = $Value"
    }
    catch {
        Write-Warn "Failed to set $Name (possibly already set or insufficient permissions)."
    }
}
Write-Info "Disabling automatic creation of administrative shares..."
Set-RegValue -Path $regPath -Name 'AutoShareWks' -Value 0
Set-RegValue -Path $regPath -Name 'AutoShareServer' -Value 0
Set-RegValue -Path $regPath -Name 'NoAdminShares' -Value 1
# --------------------------------------------------------------
# 4. Remove existing non-system shares
# --------------------------------------------------------------
$hasSmbShare = (Get-Command -Name Get-SmbShare -ErrorAction SilentlyContinue) -ne $null
foreach ($shareName in $adminShares) {
    Write-Info "Processing potential share $shareName..."
    $shareObject = if ($hasSmbShare) {
        Get-SmbShare -Name $shareName -ErrorAction SilentlyContinue
    }
    else {
        Get-CimInstance -ClassName Win32_Share -Filter "Name='$shareName'" -ErrorAction SilentlyContinue
    }
    if (-not $shareObject) {
        Write-OK "Share $shareName already does not exist."
        continue
    }
    $removed = $false
    if ($hasSmbShare) {
        try {
            Remove-SmbShare -Name $shareName -Force -Confirm:$false -ErrorAction Stop
            Write-OK "Share $shareName removed via Remove-SmbShare."
            $removed = $true
        }
        catch {
            if ($_.Exception.HResult -eq -2147023728) {
                Write-Warn "Share $shareName is a system (Admin) share, Remove-SmbShare cannot remove it."
            }
            else {
                Write-Warn "Remove-SmbShare failed to remove $shareName`: $_"
            }
        }
    }
    if (-not $removed) {
        $netOutput = net share $shareName /delete 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-OK "Share $shareName removed via net share."
        }
        else {
            if ($netOutput -match 'The request is not supported') {
                Write-Info "System share $shareName will be automatically removed after LanmanServer service restart."
            }
            else {
                Write-Warn "net share failed to remove $shareName (exit code $LASTEXITCODE): $netOutput"
            }
        }
    }
}
# --------------------------------------------------------------
# 5. Restart LanmanServer (Server) service
# --------------------------------------------------------------
function Restart-LanManServer {
    Write-Info "Restarting LanmanServer service..."
    $svcName = 'lanmanserver'
    $canUseRestartService = (Get-Command -Name Restart-Service -ErrorAction SilentlyContinue)
    if ($canUseRestartService) {
        try {
            Restart-Service -Name $svcName -Force -ErrorAction Stop
            Write-OK "Service $svcName successfully restarted (Restart-Service)."
            return
        }
        catch {
            Write-Warn "Restart-Service failed to restart ${svcName}: ${_}"
        }
    }
    try {
        sc.exe stop $svcName | Out-Null
        Start-Sleep -Seconds 2
        sc.exe start $svcName | Out-Null
        Write-OK "Service $svcName successfully restarted (sc.exe)."
    }
    catch {
        Write-Err "Failed to restart service $svcName. A full system reboot is recommended."
    }
}
Restart-LanManServer
# --------------------------------------------------------------
# 6. Summary and verification
# --------------------------------------------------------------
Write-Host "`n===== REPORT =====" -ForegroundColor Cyan
Write-Host "`n1. Registry state (auto-sharing parameters):"
try {
    Get-ItemProperty -Path $regPath -Name AutoShareWks, AutoShareServer, NoAdminShares -ErrorAction Stop `
                    | Format-List | Out-String | Write-Host
}
catch {
    Write-Err "Could not retrieve registry values from $regPath. $_"
}
Write-Host "2. Current SMB shares (after service restart):"
if ($hasSmbShare) {
    Get-SmbShare | Format-Table Name, ShareType, Path -AutoSize
}
else {
    cmd.exe /c "net share" | Out-Host
}
Write-Host "`n3. LanmanServer service status:"
Get-Service -Name lanmanserver | Format-Table Name, Status, StartType -AutoSize
Write-Host "`n✅  Administrative shares disabling completed."
Write-Host "`nIf administrative shares still appear after service restart (or full reboot), check:" -ForegroundColor DarkGray
Write-Host "  • Group Policy setting *Enable administrative shares* (should be Not Configured/Disabled)." -ForegroundColor DarkGray
Write-Host "  • Duplicate registry entries (policy might override them at boot)." -ForegroundColor DarkGray
Write-Host "`n===== END =====`n" -ForegroundColor Blue
# --------------------------------------------------------------
# End
# --------------------------------------------------------------